package TicTac;

public class execute {
    public static void main(String[] args) {
        TicTac game = new TicTac();
        game.startGame();
    }
}
